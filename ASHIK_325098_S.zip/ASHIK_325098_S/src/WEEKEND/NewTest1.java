package WEEKEND;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


import org.testng.annotations.DataProvider;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class NewTest1 {
	//registeropr rdata,rdata_out;
	//excel_io_al loginobj;
  public static WebDriver dr;
  String [][] data;
  
  @Test(dataProvider = "security")
  public void register(String fn,String ln,String eid,String pwd,String cpwd) {
	  //System.out.println("Register : "+ eid + " " + pwd );
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
	   dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/register");
		
		//choosing radio button
		List rb = dr.findElements(By.name("Gender"));
		((WebElement) rb.get(0)).click();
		
		//Registering auto
		dr.findElement(By.id("FirstName")).sendKeys(fn);
		dr.findElement(By.id("LastName")).sendKeys(ln);
		dr.findElement(By.id("Email")).sendKeys(eid);
		dr.findElement(By.id("Password")).sendKeys(pwd);
		dr.findElement(By.id("ConfirmPassword")).sendKeys(cpwd);
		dr.findElement(By.id("register-button")).click();
	  
	 
	  
  }
  
  
  @Test
  public void test1() {
	  //verification of user
		String a_prof = dr.findElement(By.className("account")).getText();
		
		System.out.println(a_prof);
		if(a_prof.equalsIgnoreCase("kibotaf25@3dmail.top")) {
			String e_prof = "kibotaf25@3dmail.top";
			System.out.println("Expected Result = " + e_prof );
			System.out.println("Actual Result = " + a_prof );
		  SoftAssert sa = new SoftAssert();
		  sa.assertEquals(a_prof,e_prof);
		  sa.assertAll();  
		}
		else if(a_prof.equalsIgnoreCase("kibotaf26@3dmail.top")) {
			String e_prof = "kibotaf26@3dmail.top";
			System.out.println("Expected Result = " + e_prof );
			System.out.println("Actual Result = " + a_prof );
		  SoftAssert sa = new SoftAssert();
		  sa.assertEquals(a_prof,e_prof);
		  sa.assertAll();  
		}
		
		
		
	  
  }
  
  @DataProvider(name = "security")
  public String[][] provide_data() {
	  String [][] data = {{"Ashton","carter","kibotaf65@3dmail.top", "qwerty123","qwerty123"},
			  			{"Ashtona","cartera","kibotaf66@3dmail.top", "qwerty123","qwerty123"}};
	  
	  return data;
	  }

}




