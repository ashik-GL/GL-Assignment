package WEEKEND2;

public class keyword_sh {
public String TC_ID;
public String step_no;
public String KeyWord;
public String Xpath;
public String Test_data;
}
