package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;




public class excel_io_al {
	static login_data ld;
	//static ArrayList<login_data> arl;
	
	
	
	
	public static login_data login (login_data ld) {
		//login_data ld = new login_data();
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		//login auto
		dr.findElement(By.id("Email")).sendKeys(ld.uid);
		dr.findElement(By.id("Password")).sendKeys(ld.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		
		
		//verifying still in same login page
		boolean f = dr.getTitle().contains("Login");
		if(!f)
		{
			ld.act = "SUCCESS";
			System.out.println("Login Success");
			if(ld.exp.equals(ld.act))
				ld.tres = "PASS";
			else
				ld.tres = "FAIL";
		}
		else
		{
			ld.act = "FAILURE";
			//catch error msg
			ld.acem1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			ld.acem2 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			
		}
		if(ld.exp.equals(ld.act) ) {
		if(ld.exp.equals("FAILURE"))
		{
			System.out.println("Exp em1 :" + ld.exem1 + "\nAct em1 :" + ld.acem1 + "\nExp em2 :" + ld.exem2 + "\nAct em2 :" + ld.acem2);
			
			if( ld.exem1.equals(ld.acem1) && ld.exem2.equals(ld.acem2))
			{
				ld.tres="PASS";
			}
			else
				ld.tres="FAIL";
		}
		}
		return ld;
		
	}
	
	
	

	

}
