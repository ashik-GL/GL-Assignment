package SDAY6;

public class xcel_data {
	String kw,xp,td;

}
