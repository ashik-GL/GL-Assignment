package SDAY6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class all_web {
	WebDriver dr;
	
	all_web (WebDriver dr)
	{
		this.dr=dr;
	}

	public void launchChrome(String url) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
	    dr = new ChromeDriver();
		dr.get(url);
		
	}

	public void enter_txt(String xp, String data) {
		// TODO Auto-generated method stub
		
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}

	public void click_btn(String xp) {
		// TODO Auto-generated method stub
		dr.findElement(By.xpath(xp)).click();
		
	}
	

}
