package SDAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest2 {
  @Test(priority=0)
  public void c() {
	  
	  String ar="noida",er="noida";
	  Assert.assertEquals(ar, er);
	  System.out.println("In test c");
  }
  
  @Test(priority=3)
  public void b() {
	  
	  String ar="noida",er="noida1";
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ar, er);
	  System.out.println("In test b");
	  sa.assertAll();
  }
  
  @Test(priority=5)
  public void a() {
	  System.out.println("In test a");
  }
  
  
}
