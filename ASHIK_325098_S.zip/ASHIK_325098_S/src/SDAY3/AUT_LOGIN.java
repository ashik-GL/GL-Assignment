package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class AUT_LOGIN {
	static login_data ld;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ld = new login_data();
		login();
		if(ld.act == "Success")
			ld.tres="Pass";
		else 
			ld.tres="Fail";
		
		read_excel();
		write_excel();
		

	}
	
	
	
	public static void login () {
		//login_data ld = new login_data();
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		//login auto
		dr.findElement(By.id("Email")).sendKeys("kibotaf795@3dmail.top");
		dr.findElement(By.id("Password")).sendKeys("qwerty123");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		//search for username displaying properly
		String a_prof = dr.findElement(By.className("account")).getText();
		String e_prof = "kibotaf795@3dmail.top";
		if(a_prof.equalsIgnoreCase(e_prof)) {
			ld.act = "Success";
			//System.out.println("Success");
		}
		else {
			ld.act = "Failed";
			//System.out.println("Failed");
		}
		
		
	}
	
	
	public static login_data read_excel() {
		
		
		try {
			File f=new File("C:\\Training\\logindata.xlsx");
			//File f=new File("C:\Training\book2.xslx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			 XSSFSheet sh = wb.getSheet("Sheet1");
			 XSSFRow r = sh.getRow(1);
			 
			 XSSFCell c = r.getCell(0);
			 ld.uid = c.getStringCellValue();
			
			 XSSFCell c1 = r.getCell(1);
			 ld.pwd = c1.getStringCellValue();
			 
			 
			 XSSFCell c2 = r.getCell(2);
			 ld.exp = c2.getStringCellValue();
			 
			System.out.println(ld.act);
			 
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return ld;
		
	}

	public static void write_excel() {
		
		//System.out.println(ld.tres);
		try {
		File f=new File("C:\\Training\\logindata.xlsx");
		//File f=new File("C:\Training\book2.xslx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		 XSSFSheet sh = wb.getSheet("Sheet1");
		 XSSFRow r = sh.getRow(1);
		
		 XSSFCell c = r.createCell(3);
		 c.setCellValue((String)ld.act);
		 XSSFCell c1 = r.createCell(4);
		 c1.setCellValue((String)ld.tres);
		 
		 FileOutputStream fos = new FileOutputStream(f);
		 wb.write(fos);
		 
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	

}
