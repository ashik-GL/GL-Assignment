package SDAY7;

public class xcel_data {
	String kw,xp,td;

}
