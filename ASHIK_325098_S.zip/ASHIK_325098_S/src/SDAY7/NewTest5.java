package SDAY7;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class NewTest5 extends basic_test_login{
	login_data ldata,ldata_out;
	excel_io_al loginobj;
	
  
  
  @Test(dataProvider = "security")
  public void login_test(String u,String p , String exp) {
	  String a_res;
	  //System.out.println("Login : "+ u + " " + p );
	 
	  a_res = login();
	
	  
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(a_res,testdata[rowno][2]);
	  sa.assertAll();
	  rowno++;
	  
  }
  @BeforeClass
  public void config() {
	  testdata = new String[2][3];
	  for(rowno=1;rowno<=2;rowno++) {
		  get_test_data();
	  }
	  rowno=0;
  }
  
  
  @DataProvider(name = "security")
  public String[][] getdata() {
	 // String [][] data = {{"kibotaf795@3dmail.top", "qwerty123","SUCCESS","",""}, {"kibotaf795@3dmail.top" , "qwerty1","FAILURE","Login was unsuccessful. Please correct the errors and try again.","The credentials provided are incorrect"}};
	  
	  return testdata;
	  }

}
