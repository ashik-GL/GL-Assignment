package SDAY11;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_read {
	
	public static String  filename = "C:\\Training\\kydreglogin3.xlsx";
	public static String  kw_sheet = "KEYWORD";
	public static String  tc_sheet = "TC_SELECTION_SH";
	public static XSSFSheet kw_sh_obj, tc_sh_obj, td_sh_obj;
	//public static ArrayList<login_test_data> td_al;
	
	public static XSSFSheet set_sheet(String sheetname) 
	{
		XSSFSheet sh = null;
		
		File f = new File(filename);
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			sh = wb.getSheet(sheetname);
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sh;
		
		
	}
	
	public static tc_selection read_TC_SELECTION_SH(int j)
	{
		tc_selection td = new tc_selection();
		tc_sh_obj = set_sheet(tc_sheet);
		
		XSSFRow rw = tc_sh_obj.getRow(j);
		td.tid = rw.getCell(0).getStringCellValue();
		td.flag = rw.getCell(1).getStringCellValue();
		td.not = (int) rw.getCell(2).getNumericCellValue();
		//td.tds = rw.getCell(3).getStringCellValue();
		
		
		
		return td;
	
	}
	
	public static keyword_sh read_kw_sh(int i) {
		keyword_sh kw = new keyword_sh();
		kw_sh_obj = set_sheet(kw_sheet);
		
		XSSFRow rw = kw_sh_obj.getRow(i);
		kw.tc_id = rw.getCell(0).getStringCellValue();
		kw.tstep = rw.getCell(1).getStringCellValue();
		kw.kwd = rw.getCell(2).getStringCellValue();
		kw.xp = rw.getCell(3).getStringCellValue();
		kw.tdata = rw.getCell(4).getStringCellValue();
		return kw;
		
	}
	
	public static void get_test_data(String shname,int total_rows,int total_cols) {
		td_sh_obj = set_sheet(shname);
		
		
	}
	

	

}
