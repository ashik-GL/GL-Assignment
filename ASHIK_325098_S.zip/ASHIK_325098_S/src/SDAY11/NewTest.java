package SDAY11;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class NewTest {
	@FindBy(xpath="//*[@id=\"user-name\"]")
	WebElement eid;
	
	
	@FindBy(xpath="//*[@id=\"password\"]" )
	WebElement pwd;
	
	@FindBy(xpath="//*[@id=\"login_button_container\"]/div/form/input[3]")
	WebElement btn;
	
  @Test
  public void f() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		
		PageFactory.initElements(dr, this);
		//login
		eid.sendKeys("standard_user");
		pwd.sendKeys("secret_sauce");
		btn.click();
  }
}
