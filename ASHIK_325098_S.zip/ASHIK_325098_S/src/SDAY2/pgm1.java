package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		
		/*String title = dr.getTitle();
		System.out.println("Title is :" + title);
		*/
		/*List rb = dr.findElements(By.name("sex"));
		((WebElement) rb.get(0)).click();
		for(int i=0;i<rb.size();i++) {
			System.out.println(rb.get(i));
		}*/
		
		
		dr.findElement(By.id("email")).sendKeys("ashikmoosa96@gmail.com");
		dr.findElement(By.id("pass")).sendKeys("NoNames3#");
		dr.findElement(By.id("loginbutton")).click();
		
	/*	String a_prof = dr.findElement(By.className("_1vp5")).getText();
		String e_prof = "Frank";
		
		if(a_prof.equalsIgnoreCase(e_prof)) {
			System.out.println("Login Success!!");
		}
		else {
			System.out.println("Login Failed!!");
		}*/
		
		
		
	}
}

