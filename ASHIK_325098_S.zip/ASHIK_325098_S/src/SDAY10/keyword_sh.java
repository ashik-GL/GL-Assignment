package SDAY10;

public class keyword_sh {
	String tc_id,tstep,kwd,xp,tdata,tres;

}
