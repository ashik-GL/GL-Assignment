package SDAY10;

public class tc_selection {
	String tid,flag,tds,tres;
	int not;
}
