package SDAY10;

import org.openqa.selenium.WebDriver;

import SDAY7.all_web;

public class HFW extends excel_read{

	static keyword_sh d = new keyword_sh();
	static tc_selection td = new tc_selection();
    static String  filename = "C:\\Training\\Hybrid2.xlsx"; 
    //excel_read er = new excel_read();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String id,ch,testdata=null;
		WebDriver dr = null;
		all_web we = new all_web(dr);
		//HFW hf = new HFW();
		int i,j,k=0;
		for(i=1;i<=3;i++) 
		{
			td = read_TC_SELECTION_SH(i);
			//System.out.println(td.flag);
			if((td.flag).equals("Y")) {
				System.out.println(td.tid);
				
				for(j=1;j<20;j++) {
						d=excel_read.read_kw_sh(j);
						//System.out.println(ksh.TC_ID);
									
						if(d.tc_id.equals(td.tid)) {	
									System.out.println("yes");
									break;
						}
						else
						{
									continue;			
						}
						
										
				}
				get_test_data(td.tds, 2, 2);
				for(login_test_data data:td_al) {
					for(k=j;k<=((j+td.not)-1);k++) {
						if(k==(j+2)) {testdata=data.uid;}
						if(k==(j+3)) {testdata=data.pwd;}
						
						d= excel_read.read_kw_sh(k);
						ch=d.kwd;
						System.out.println("Testdata : " + testdata);
						switch(ch)
						{
						case "launchchrome":
							System.out.println("Launching chrome");
							we.launchChrome(d.tdata);
							break;
							
						case "enter_txt":
							we.enter_txt(d.xp,d.tdata);
							break;
							
						case "click_btn":
							we.click_btn(d.xp);
							break;
							
						case "click_rb" :
							we.click_rbtn();
							break;
							
						case "verify" :
							we.verify(d.tdata);
							break;
							
						case "closebrowser" :
							we.closebrow();
							break;
						
						
						
					}
				}
					if(k==(j+td.not))
					{
						System.out.println("pass");
					}
					else
					{
						System.out.println("fail");
					}
			
		}
		
		
		

	}

}
}
}
