package SDAY5;

import org.testng.annotations.Test;

public class NewTest3 {
	
	login_data ldata,ldata_out;
	excel_io_al loginobj;
	
  @Test
  public void t1() {
	  
	  ldata = new login_data();
	  ldata_out = new login_data();
	  loginobj = new excel_io_al();
	  
	  ldata.uid="kibotaf795@3dmail.top";
	  ldata.pwd = "qwerty123";
	  ldata.exp="SUCCESS";
	  
	  ldata_out = loginobj.login(ldata);
	  System.out.println("ldata_out.act_res : " + ldata_out.act);
	  
	  
	  
	  
	  
  }
}
