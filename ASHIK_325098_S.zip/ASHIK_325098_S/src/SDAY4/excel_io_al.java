package SDAY4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;




public class excel_io_al {
	static login_data ld;
	static ArrayList<login_data> arl;
	static int row=1;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ld = new login_data();
		
		for(int i=1;i<=3;i++) {
		read_excel(i);
		login();
		write_excel(i);
		}
		

	}
	
	
	
	public static void login () {
		//login_data ld = new login_data();
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		//login auto
		dr.findElement(By.id("Email")).sendKeys(ld.uid);
		dr.findElement(By.id("Password")).sendKeys(ld.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		
		
		//verifying still in same login page
		boolean f = dr.getTitle().contains("Login");
		if(!f)
		{
			ld.act = "SUCCESS";
			System.out.println("Login Success");
			if(ld.exp.equals(ld.act))
				ld.tres = "PASS";
			else
				ld.tres = "FAIL";
		}
		else
		{
			ld.act = "FAILURE";
			//catch error msg
			ld.acem1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			ld.acem2 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			
		}
		if(ld.exp.equals(ld.act) ) {
		if(ld.exp.equals("FAILURE"))
		{
			System.out.println("Exp em1 :" + ld.exem1 + "\nAct em1 :" + ld.acem1 + "\nExp em2 :" + ld.exem2 + "\nAct em2 :" + ld.acem2);
			
			if( ld.exem1.equals(ld.acem1) && ld.exem2.equals(ld.acem2))
			{
				ld.tres="PASS";
			}
			else
				ld.tres="FAIL";
		}
		}
		
	}
	
	
	public static login_data read_excel(int i) {
		//arl = new ArrayList<login_data>();
		//for(int i=1;i<=2;i++) {
		try {
			File f=new File("C:\\Training\\logindata2.xlsx");
			//File f=new File("C:\Training\book2.xslx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			 XSSFSheet sh = wb.getSheet("Sheet1");
			 XSSFRow r = sh.getRow(i);
			 
			 XSSFCell c = r.getCell(0);
			 ld.uid = c.getStringCellValue();
			
			 XSSFCell c1 = r.getCell(1);
			 ld.pwd = c1.getStringCellValue();
			 
			 
			 XSSFCell c2 = r.getCell(2);
			 ld.exp = c2.getStringCellValue();
			 
			 if((ld.exp).contains("FAILURE")) {
			 XSSFCell c3 = r.getCell(3);
			 ld.exem1 = c3.getStringCellValue();
			 
			 XSSFCell c4 = r.getCell(4);
			 ld.exem2 = c4.getStringCellValue();
			 }
			//System.out.println(ld.act);
			 
			//arl.add(ld);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	//	}
		return ld;
		
	}

	public static void write_excel(int row) {
		
		//System.out.println(ld.tres);
		try {
			
		File f=new File("C:\\Training\\logindata2.xlsx");
		//File f=new File("C:\Training\book2.xslx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		 XSSFSheet sh = wb.getSheet("Sheet1");
		// for(login_data ld: arl) {
		 XSSFRow r = sh.getRow(row);
		
		 XSSFCell c = r.createCell(5);
		 c.setCellValue((String)ld.act);
		// System.out.println(ld.act);
		 
		 XSSFCell c3 = r.createCell(8);
		 c3.setCellValue((String)ld.tres);
		 
		 if(ld.exp.contains("FAILURE")) {
		 XSSFCell c1 = r.createCell(6);
		 c1.setCellValue((String)ld.acem1);
		
		 XSSFCell c2 = r.createCell(7);
		 c2.setCellValue((String)ld.acem2);
		 }
		 
		
		 
		 FileOutputStream fos = new FileOutputStream(f);
		 wb.write(fos);
		// row++;
		// }
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	

}
