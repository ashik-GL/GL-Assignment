package DAY11;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bank b;
		b=new icici();
		System.out.println("ICICI ROI : " + b.get_roi());
		
		b=new hdfc();
		System.out.println("HDFC ROI : " + b.get_roi());
		

	}

}
