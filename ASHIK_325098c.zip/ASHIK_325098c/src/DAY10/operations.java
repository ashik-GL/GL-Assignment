package DAY10;

import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY8.passenger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class operations {
	ArrayList<table1> psg_al1;
	ArrayList<table2> psg_al2;
    ArrayList<table3> psg_al3;
	
	
	public void read_excel_t1() {
		
		psg_al1 = new ArrayList<table1>();
		for(int i=1;i<=2;i++) {
			
			
			table1 t1 = new table1();
			File f = new File("C:\\Training\\customer.xlsx");
			FileInputStream fis;
			try {
				fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet1");
				XSSFRow r = sh.getRow(i);
				
				XSSFCell c = r.getCell(0);
				t1.route_id = (int) c.getNumericCellValue();
				
				XSSFCell c1 = r.getCell(1);
				t1.from = c1.getStringCellValue();
				
				XSSFCell c2= r.getCell(2);
				t1.to = c2.getStringCellValue();
				
				XSSFCell c3 = r.getCell(3);
				t1.unitprice= (int) c3.getNumericCellValue();
				
				psg_al1.add(t1);	
				
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
	}
	
public void read_excel_t2() {
	psg_al2 = new ArrayList<table2>();
		
		for(int i=1;i<=2;i++) {
			
			
			table2 t2 = new table2();
			File f = new File("C:\\Training\\customer.xlsx");
			FileInputStream fis;
			try {
				fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet2");
				XSSFRow r = sh.getRow(i);
				
				XSSFCell c = r.getCell(0);
				t2.customer_id = (int) c.getNumericCellValue();
				
				XSSFCell c1 = r.getCell(1);
				t2.c_name = c1.getStringCellValue();
				
				psg_al2.add(t2);	
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
	}

public void read_excel_t3() {
	
	psg_al3 = new ArrayList<table3>();
	for(int i=1;i<=2;i++) {
		
		
		table3 t3 = new table3();
		File f = new File("C:\\Training\\customer.xlsx");
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet3");
			XSSFRow r = sh.getRow(i);
			
			XSSFCell c = r.getCell(0);
			t3.cid = (int) c.getNumericCellValue();
			
			XSSFCell c1 = r.getCell(1);
			t3.rid= (int) c1.getNumericCellValue();
			
			XSSFCell c2 = r.getCell(2);
			t3.not= (int) c2.getNumericCellValue();
			
			psg_al3.add(t3);	
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
	
	
public void write_excel(table4 t4) {
		
		try {
			
			File f = new File("C:\\Training\\customer.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet4");
			int row=1;
			XSSFRow r = sh.createRow(row);
			XSSFCell c = r.createCell(0);
			c.setCellValue((double)t4.customer_id);
				
			XSSFCell c1 = r.createCell(1);
			c1.setCellValue(t4.c_name);
				
			XSSFCell c2 = r.createCell(2);
			c2.setCellValue(t4.from);
				
			XSSFCell c3 = r.createCell(3);
			c3.setCellValue(t4.to);
				
			XSSFCell c4= r.createCell(4);
			c4.setCellValue(t4.unitprice);
				
			XSSFCell c5 = r.createCell(5);
			c5.setCellValue(t4.not);
				
			XSSFCell c6 = r.createCell(6);
			c6.setCellValue(t4.price);
				
				
				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
				row++;
				
			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}
	
		

