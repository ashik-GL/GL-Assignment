package DAY10;

public class table2 {
	int customer_id;
	String c_name;
}
