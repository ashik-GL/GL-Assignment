package DAY10;

import java.util.ArrayList;

public class calculation extends operations {
	table3 tt3;
	table4 t4;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		calculation c1 = new calculation();
		c1.read_excel_t1();
		c1.read_excel_t2();
		c1.read_excel_t3();
		c1.t4 = new table4();
		c1.tt3 = c1.psg_al3.get(0);
		
		
		c1.searcht2(c1.tt3.cid);
		c1.searcht1(c1.tt3.rid);
		c1.t4.not = c1.tt3.not;
		c1.t4.customer_id=c1.tt3.cid;
		c1.t4.price = c1.t4.unitprice * c1.t4.not;
		c1.write_excel(c1.t4);
		
		
		
		

	}

	private void searcht1(int lrid) {
		// TODO Auto-generated method stub
		for(table1 tt1:psg_al1) {
			if(tt1.route_id==lrid) {
				t4.from = tt1.from;
				t4.to=tt1.to;
				t4.unitprice=tt1.unitprice;
				break;
			}
		}
		
	}

	private void searcht2(int lcid) {
		// TODO Auto-generated method stub
		for(table2 tt2:psg_al2) {
			if(tt2.customer_id==lcid) {
				t4.c_name=tt2.c_name;
				break;
			}
		}
		
	}

	

}
