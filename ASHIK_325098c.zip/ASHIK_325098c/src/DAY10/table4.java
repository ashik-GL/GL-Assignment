package DAY10;

public class table4 {
	int customer_id;
	String c_name;
	String from;
	String to;
	int unitprice;
	int not;
	int price;
}
