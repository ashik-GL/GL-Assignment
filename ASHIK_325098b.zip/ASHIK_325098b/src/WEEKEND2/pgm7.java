package WEEKEND2;

import java.util.ArrayList;

import DAY7.operationsdemo;
import DAY7.student;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<product> al = new ArrayList<product>();
		//operations op = new operations();
		operations op1 = new operations();
		
		
		al=op1.read_excel();
		
		op1.write_excel(al);

	}

}
