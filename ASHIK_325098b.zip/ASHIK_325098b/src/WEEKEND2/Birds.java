package WEEKEND2;

public class Birds {
	
	int nol;
	String color;
	String food;
	String name;
	String gender;
	int age;
	
	
	public void flys() {
		System.out.println("The Bird Flys\n");
	}
	
	public void eats() {
		System.out.println("The Bird eats\n");
	}	
	
	public void display() {
		System.out.println(" No of legs: " +this.nol + " Skin color: "+ this.color + " Food: " + this.food + " Name: "+this.name 
							+ " Gender: " + this.gender + " Age: " + this.age );
	}
	
}
