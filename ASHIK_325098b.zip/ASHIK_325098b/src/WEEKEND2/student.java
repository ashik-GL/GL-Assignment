package WEEKEND2;

public class student {
	public int rollno;
	public String name;
	public int java;
	public int selenium;
	public float avg;
	public void average() {
		avg=(float) (java+selenium)/2;
		
	}

	public student(int rollno,String name,int java,int selenium) {
		this.name=name;
		this.rollno=rollno;
		this.java=java;
		this.selenium=selenium;
	}
}

