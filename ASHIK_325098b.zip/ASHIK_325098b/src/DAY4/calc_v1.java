package DAY4;

public class calc_v1 {

	
		// TODO Auto-generated method stub
		public int add(int x,int y) {
			int z=x+y;
			return z;
		}
		public float add(float x,float y) {
			float z=x+y;
			return z;
			
		}
		
		public float add(float x,int y) {
			float z= x+y;
			return z;
			
		}
		public float add(int i, int j, float f) {
			// TODO Auto-generated method stub
			return i+j+f;
			
		}
		
}
