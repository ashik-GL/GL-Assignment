package DAY5;

public class student {
	public int rollno;
	public String name;
	public int m1;
	public int m2;
	public float avg;
	public void average() {
		avg=(float) (m1+m2)/2;
		
	}

}

