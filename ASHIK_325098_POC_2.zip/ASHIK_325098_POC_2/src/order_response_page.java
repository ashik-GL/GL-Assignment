

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class order_response_page {
	WebDriver dr;
	
	
	public order_response_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public void switch_pages() {
		String hndcpage = dr.getWindowHandle();
		for(String handle : dr.getWindowHandles())
		{
			dr.switchTo().window(handle);
			String title = dr.getTitle();
			System.out.println(title);
			
		}
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void denynot() {
		try {
			Thread.sleep(9000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		dr.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/button[1]")).click();
	}
	
	public void cancel_order() {
		
		System.out.println(dr.getTitle());
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//click cod order or place order
		dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div/div/div[3]/div[1]/div[3]/div[2]/div[1]/span/span")).click();
		
	}
	
	public void click_continue() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//select from drop down
		Select drpview = new Select(dr.findElement(By.name("reasonList")));
		drpview.selectByValue("purchased_mistake");
		
		
		System.out.println(dr.getTitle());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[4]/div[1]/div[1]/div/div/div/div[3]/button")).click();
		
		
		dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[4]/div[1]/div[2]/div/div/div/div/div/div/button")).click();
	}
	
	

}
