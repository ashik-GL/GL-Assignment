

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class test1 {
	
	login_page lp;
	home_page hp;
	WebDriver dr;
	cart_page cp;
	add_to_cart_page acp;
	product_page pp;
	check_out_page cop;
	order_response_page orp;
	
	
  @Test
  public void t1() {
	  lp.do_login("9318399055", "KroMoz702#"); 
  }
  
  @Test
  public void t2() {
	  hp.search_prod();  
  }
  
  @Test
  public void t3() {
	  pp.filter_rate();
	  pp.filter_price();
	  pp.select_product();
  }
  
  @Test
  public void t4() {
	  System.out.println(dr.getTitle());
	  acp.switch_pages();
	  acp.click_add_cart();
	 
	  
  }
  
  @Test
  public void t5() {
	  System.out.println(dr.getTitle());
	  cp.switch_pages();
	  cp.place_order();
	  
	 
  }
  
  @Test
  public void t6() {
	  System.out.println(dr.getTitle());
	  cop.check_out();
	  cop.radio_btn();
	  
  }
  
  @Test
  public void t7() {
	  System.out.println(dr.getTitle());
	  orp.switch_pages();
	  orp.denynot();
	  orp.cancel_order();
	  orp.click_continue();
	 
	  
  }
  
  
  
  @BeforeClass
  public void bc() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr = new ChromeDriver();
		
		dr.get("https://www.flipkart.com/");
		

		lp = new login_page(dr);
		hp = new home_page(dr);
		cp = new cart_page(dr);
		acp = new add_to_cart_page(dr);
		pp = new product_page(dr);
		cop = new check_out_page(dr);
		orp = new order_response_page(dr);
	  
  }

}
