

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class add_to_cart_page {
	WebDriver dr;
	
	
	public add_to_cart_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	
	public void switch_pages() {
		
		String hndacpage = dr.getWindowHandle();
		for(String handle : dr.getWindowHandles())
		{
			dr.switchTo().window(handle);
			String title = dr.getTitle();
			System.out.println(title);
			
		}
		
		
		
	}
	
	public void click_add_cart() {
		dr.manage().window().maximize();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String dod = dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div[1]/div[2]/div[4]/div/div/div[2]/div[1]/ul/div/div/span[1]")).getText();
		int flag=0;
		int tday = 22;
		if(dod.contains("Tomorrow")) {
			flag=1;
		}
		else if(dod.contains("Today")) {
			flag = 1;
		}
		else {
			//use regular expr to extract int from string
			int intValue = Integer.parseInt(dod.replaceAll("[^0-9]", "")); 
			int totaldf = intValue - tday;
			//System.out.println("inside regular expresssion");
			if(totaldf<=4)
				flag=1;
		}
		//System.out.println("Flag Value is :" + flag);
		//add product to cart
		if(flag==1) {
			
			dr.findElement(By.xpath("//*[text()='ADD TO CART']")).click();
		}

	}
	
	
	
	
	
	
	
	
	
	

}
