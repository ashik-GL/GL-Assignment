

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class check_out_page {
	WebDriver dr;
	
	
	public check_out_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	
	public void check_out() {
		System.out.println(dr.getTitle());
		
		//click continue
		dr.findElement(By.xpath("//*[@id=\"to-payment\"]/button")).click();
		
	}
	
	public void radio_btn() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[1]/div/label[4]")).click();
	}

}
