

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class login_page {
	static WebDriver dr;
	static By xuname = By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input");
	static By xpwd = By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input");
	static By xbtn = By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button");
	
	public login_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public static void enter_username(String uid) {
		dr.findElement(xuname).sendKeys(uid);
	}
	
	public void enter_pword(String pword) {
		dr.findElement(xpwd).sendKeys(pword);
	}
	
	public void click_btn (){
		dr.findElement(xbtn).click();
	}
	
	public void do_login(String uid,String pword) {
		this.enter_username(uid);
		this.enter_pword(pword);
		this.click_btn();
	}
	
	public String get_loginpage_title() {
		return dr.getTitle();
	}
	
	
	
	
	
	
	
	
	
	
	
}
