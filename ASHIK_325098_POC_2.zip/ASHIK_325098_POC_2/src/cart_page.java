

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart_page {
	WebDriver dr;
	
	
	public cart_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public void switch_pages() {
		String hndcpage = dr.getWindowHandle();
		for(String handle : dr.getWindowHandles())
		{
			dr.switchTo().window(handle);
			String title = dr.getTitle();
			System.out.println(title);
			
		}	
	}
	
	public void place_order() {
		
		System.out.println(dr.getTitle());
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//click cod order or place order
		dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div[2]/div/div[1]/div/div[3]/div/form/button")).click();
		
		
		
	}
	
	public void click_continue() {
		System.out.println(dr.getTitle());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(By.xpath("//*[@id=\"to-payment\"]/button")).click();
	}

}
