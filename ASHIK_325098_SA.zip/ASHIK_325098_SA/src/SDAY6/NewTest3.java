package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest3 {
	
	login_data ldata,ldata_out;
	excel_io_al loginobj;
	
  @Test
  public void t1() {
	  
	  ldata = new login_data();
	  ldata_out = new login_data();
	  loginobj = new excel_io_al();
	  
	  ldata.uid="kibotaf795@3dmail.top";
	  ldata.pwd = "qwerty123";
	  ldata.exp="SUCCESS";
	  
	  ldata_out = loginobj.login(ldata);
	  System.out.println("ldata_out.act_res : " + ldata_out.act);
	  
	  
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ldata_out.act,ldata_out.exp);
	  sa.assertAll();
	  
  }
  
  @Test
  public void t2() {
	  
	  ldata = new login_data();
	  ldata_out = new login_data();
	  loginobj = new excel_io_al();
	  
	  ldata.uid="kibotaf795@3dmail.top";
	  ldata.pwd = "qwerty";
	  ldata.exp="SUCCESS";
	  ldata.exem1="Login was unsuccessful. Please correct the errors and try again.";
	  ldata.exem2="The credentials provided are incorrect";
	  
	  ldata_out = loginobj.login(ldata);
	  System.out.println("ldata_out.act_res : " + ldata_out.act);
	  
	  
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ldata_out.act,ldata_out.exp);
	  sa.assertAll();
	  
	  
	  
	    
  }
  
  
}
