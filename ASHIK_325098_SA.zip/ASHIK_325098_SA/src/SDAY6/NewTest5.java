package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class NewTest5 {
	login_data ldata,ldata_out;
	excel_io_al loginobj;
	
  
  @BeforeClass
  public void beforeClass() {
	  ldata = new login_data();
	  ldata_out = new login_data();
	  loginobj = new excel_io_al();
	  
  }
  
  
  @Test(dataProvider = "security")
  public void login(String u,String p,String exp,String exem1,String exem2) {
	  System.out.println("Login : "+ u + " " + p );
	  ldata.uid=u;
	  ldata.pwd=p;
	  ldata.exp=exp;
	  if((ldata.exp).contains("FAILURE")) {
		  ldata.exem1=exem1;
		  ldata.exem2=exem2;
	  }
	  ldata_out = loginobj.login(ldata);
	  
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ldata_out.act,ldata_out.exp);
	  sa.assertAll();
	  
	  
  }
  
  
  @DataProvider(name = "security")
  public String[][] getdata() {
	  String [][] data = {{"kibotaf795@3dmail.top", "qwerty123","SUCCESS","",""}, {"kibotaf795@3dmail.top" , "qwerty1","FAILURE","Login was unsuccessful. Please correct the errors and try again.","The credentials provided are incorrect"}};
	  
	  return data;
	  }

}
