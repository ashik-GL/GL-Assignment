package SDAY6;

import org.openqa.selenium.WebDriver;

public class keyword_driven_framework  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw,xp,td,z,y,x;
		WebDriver dr = null;
		all_web we = new all_web(dr);
		operations excel = new operations();
		xcel_data xd = new xcel_data();
		for(int r=1;r<=4;r++) {
			z = excel.read_excel(r,3);
			y = excel.read_excel(r,4);
			x = excel.read_excel(r,5);
			/*System.out.println(xd.kw);
			System.out.println(xd.xp);
			System.out.println(xd.td);*/
			//String a = xd.kw;
			
			/*System.out.println("z = " + z);
			if(z.equals("launchchrome"))
			{ 
				System.out.println("launchchrome");
				we.launchChrome(xd.td);
			}
			else
				System.out.println("not launchchrome");
				*/
				
		switch(z)
		{
		case "launchchrome":
			System.out.println("Launching chrome");
			we.launchChrome(x);
			break;
			
		case "enter_txt":
			we.enter_txt(y,x);
			break;
			
		case "click_btn":
			we.click_btn(y);
			break;
			
		//default: System.out.println("error");
			
		}
		}

	}

}
