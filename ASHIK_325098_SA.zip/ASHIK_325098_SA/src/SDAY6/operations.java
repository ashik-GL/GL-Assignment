package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class operations {
	
	public String read_excel(int r1 , int col1) {
		xcel_data s = new xcel_data();
		String ss = null;
		try {
			
			File f=new File("C:\\Training\\loginkyd.xlsx");
			//File f=new File("C:\Training\book2.xslx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			 XSSFSheet sh = wb.getSheet("Sheet1");
			 XSSFRow r = sh.getRow(r1);
			 
			
		    XSSFCell c = r.getCell(col1);
		     ss = c.getStringCellValue();
		    //col1++;
				
			 /*XSSFCell c1 = r.getCell(col1);
			 s.xp = c1.getStringCellValue();
			 col1++;
			 
			 XSSFCell c2 = r.getCell(col1);
			 s.td = c2.getStringCellValue();
			*/
			 
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ss;	
	}
	
	

}
