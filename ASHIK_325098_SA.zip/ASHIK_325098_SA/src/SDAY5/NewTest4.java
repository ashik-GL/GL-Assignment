package SDAY5;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class NewTest4 {
  @Test
  public void a() {
	  System.out.println("I met Mr.Dhoni");
  }
  
  @Test
  public void b() {
	  System.out.println("I had lunch with Mr. Virat Kohli");
  }
  
  @Test
  public void c() {
	  System.out.println("I took a pic with Mr.Rohit Sharma");
  }
  
  
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Hello");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("Bye");
  }

  @BeforeClass
  public void beforeClass() {
	  System.out.println("I came to the cricket stadium");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("Now I am back home");
  }

}
