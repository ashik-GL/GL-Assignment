package SDAY5;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class NewTest2 {
  @Test
  public void a() {
	  System.out.println("In test a");
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("BM");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("AM");
  }
  
  @Test
  public void b() {
	  System.out.println("In test b");
  }
  
  @Test
  public void c() {
	  System.out.println("In test c");
  }

}
