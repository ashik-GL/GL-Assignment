package SDAY4;

public class login_data {
	String uid,pwd,exp,exem1,exem2,act,acem1,acem2,tres;
	
	
}
