package SDAY4;

import javax.sound.midi.SysexMessage;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
		dr.findElement(By.name("cusid")).sendKeys("Frank");
		dr.findElement(By.name("submit")).click();
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Alert a = dr.switchTo().alert();
		String s = a.getText();
		System.out.println(s);
		//a.dismiss();
		a.accept();
		try {
			Thread.sleep(3000);
		
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Alert a1 = dr.switchTo().alert();
		s= a1.getText();
		a1.accept();
		System.out.println(s);
		
		
		
		
		
		
		
		
		
		
	}

}
