package SDAY3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		//login_data ld = new login_data();
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/register");
		
		//choosing radio button
		List rb = dr.findElements(By.name("Gender"));
		((WebElement) rb.get(0)).click();
		
		//Registering auto
		dr.findElement(By.id("FirstName")).sendKeys("Frank");
		dr.findElement(By.id("LastName")).sendKeys("Martin");
		dr.findElement(By.id("Email")).sendKeys("bovij30664@netmail8.com");
		dr.findElement(By.id("Password")).sendKeys("qwerty123");
		dr.findElement(By.id("ConfirmPassword")).sendKeys("qwerty123");
		dr.findElement(By.id("register-button")).click();
		
		//verification of user
		String a_prof = dr.findElement(By.className("account")).getText();
		String e_prof = "bovij30664@netmail8.com";
		if(a_prof.equalsIgnoreCase(e_prof)) {
			//ld.act = "Success";
			System.out.println("Success");
		}
		else {
			//ld.act = "Failed";
			System.out.println("Failed");
		}
		dr.findElement(By.className("ico-logout")).click();
		
		dr.close();
		
	}
}
