package SDAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1b {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
		
		try {
			dr.wait(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 dr.findElement(By.name("button1")).click();
		String a_prof = dr.findElement(By.className("entry-title")).getText();
		String e_prof = "Button success";
		if(a_prof.equalsIgnoreCase(e_prof)) {
			System.out.println("Button Click Success");
		}
		else {
			System.out.println("Button Click Failed");
		}
		
		
	}

}
