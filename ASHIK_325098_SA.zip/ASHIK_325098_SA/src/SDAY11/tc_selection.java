package SDAY11;

public class tc_selection {
	String tid,flag,tds,tres;
	int not;
}
