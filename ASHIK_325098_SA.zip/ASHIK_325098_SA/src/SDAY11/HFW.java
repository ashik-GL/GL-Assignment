package SDAY11;

import org.openqa.selenium.WebDriver;

import SDAY7.all_web;

public class HFW extends excel_read{

	static keyword_sh d = new keyword_sh();
	static tc_selection td = new tc_selection();
    static String  filename = "C:\\Training\\kydreglogin3.xlsx"; 
    
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String id,ch,testdata=null;
		String kw,xp,tdd,z,y,x;
		WebDriver dr = null;
		all_web we = new all_web(dr);
		int i,j,k=0;
		for(i=1;i<=3;i++) 
		{
			td = read_TC_SELECTION_SH(i);
			//System.out.println(td.flag);
			if((td.flag).equals("Y")) {
				System.out.println(td.tid);
				
				for(j=1;j<20;j++) {
					d = read_kw_sh(j);
					if(td.tid.equals(d.tc_id)) {
						System.out.println("found");
						break;
					}
					else 
						continue;
				}
				
				for(k=j;k<=td.not;k++) {
					d = read_kw_sh(k);
					
					switch(d.kwd)
					{
					case "launchchrome":
						System.out.println("Launching chrome");
						we.launchChrome(d.tdata);
						break;
						
					case "enter_txt":
						we.enter_txt(d.xp,d.tdata);
						break;
						
					case "click_btn":
						we.click_btn(d.xp);
						break;
						
					case "click_rb" :
						we.click_rbtn();
						break;
						
					case "verify" :
						we.verify(d.tdata);
						break;
						
					case "closebrowser" :
						we.closebrow();
						break;
						
					//default: System.out.println("error");
						
					}
				
				
				
			}
			
		}
		
		
		

	}

}
}
