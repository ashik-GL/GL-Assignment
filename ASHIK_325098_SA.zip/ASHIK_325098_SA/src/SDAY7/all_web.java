package SDAY7;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

public class all_web extends excel_io_al{
	WebDriver dr;
	
	public all_web (WebDriver dr)
	{
		this.dr=dr;
	}

	public void launchChrome(String url) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
	    dr = new ChromeDriver();
		dr.get(url);
		
	}

	public void enter_txt(String xp, String data) {
		// TODO Auto-generated method stub
		
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}

	public void click_btn(String xp) {
		// TODO Auto-generated method stub
		dr.findElement(By.xpath(xp)).click();
		
	}
	
	public void click_rbtn() {
		List rb = dr.findElements(By.name("Gender"));
		((WebElement) rb.get(0)).click();
		}

	public void closebrow() {
		// TODO Auto-generated method stub
		dr.close();
	}

	public void verify(String td) {
		// TODO Auto-generated method stub
		String act;
		//verifying register
		act = dr.findElement(By.className("account")).getText();
		if(act.equals(td)) {
			String str = "SUCCESS";
			write_excel(str);
		}
		
	}
	

}
