package DAY3;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num= {21,34,91,59,16,25,29,74,49,82};
		int sum=0;
		for(int i=0;i<10;i++) {
			if(even(num[i])) {
				sum=sum+num[i];
			}
		}
		
		System.out.println("The sum is: "+ sum);
		}
	
	public static boolean even(int z) {
		if(z%2==0) {
			return true;
		}
		
		return false;
	}
	

}
