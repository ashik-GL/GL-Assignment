package DAY2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//print sum of nums div by 7 btw 15 & 75 using while
		int sum=0;
		int i=15;
		while(i<75) {
			if(i%7==0) {
				sum=sum+i;
			}
			i++;
		}
		System.out.println(sum);
	}

}
