package DAY2;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int z=add(5,6);
		System.out.println(z);

	}
	
	public static int add(int a,int b) {
		int sum=0;
		sum=a+b;
		return sum;
	}
}
