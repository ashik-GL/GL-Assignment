package PKG_1;

import org.testng.annotations.Test;

public class test1 {
  @Test
  public void f() {
	  System.out.println("Maven 1 PKG_1 test1");
  }
}
