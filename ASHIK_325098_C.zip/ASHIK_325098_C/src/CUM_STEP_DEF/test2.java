package CUM_STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
  
	WebDriver dr;
	@When("^User enters invalid login details$")
	public void user_enters_invalid_login_details() throws Throwable {
		dr = test1.dr;
		System.out.println("User enters invalid login details");
		dr.findElement(By.id("Email")).sendKeys("kibotaf795@3dmail.top");
		dr.findElement(By.id("Password")).sendKeys("qwerty");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	   
	}

	@Then("^Login is unsuccessful$")
	public void login_is_unsuccessful() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		String em1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();

		String em2 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		
		System.out.println(em1 + "\n" + em2);
		
	}
}
