$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 2,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "To verify login for valid data",
  "description": "",
  "id": "aut-login;to-verify-login-for-valid-data",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@Round1"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters login details",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "Home page is displayed",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});