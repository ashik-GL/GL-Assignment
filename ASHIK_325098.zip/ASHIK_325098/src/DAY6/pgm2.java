package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str_al = new ArrayList<String>();
		str_al.add("Ashik");
		str_al.add("Peter");
		str_al.add("Bruce");
		for(String s:str_al) {
			System.out.println(s);
		}
		
		str_al.remove("Ashik");
		System.out.println("After deleting");
		System.out.println(str_al);
		
		str_al.add(1, "Harvey");
		str_al.add("Joker");
		System.out.println("After adding");
		System.out.println(str_al);
		
	
		
		System.out.println("After Get : " + str_al.get(3));

	}

}
