package DAY6;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Elephant e1 = new Elephant(7,6,28,"Black","Tree bark","male","Mangalamkunnu karnan",4);
		Elephant e2 = new Elephant(6,5,33,"Black","twigs","male","Chirakkal Kalidasan",4);
		Tiger t1 = new Tiger(6,7);
		Tiger t2 = new Tiger(7,9);
		
		
		e1.display();
		e1.eats();
		e1.swim();
		
		
		e2.display();
		e2.spraying();
		e2.acts();
		
		
		/*You can use both methods either with constructor initialization or direct
		
		t1.age=24;
		t1.color="Red-Orange";
		t1.food="Deers";
		t1.gender="male";
		t1.name="Shere khan";
		t1.climb();
		t1.eats();
		t1.mauls();
		t1.roar();
		t1.display();
		
		t2.age=24;
		t2.color="White";
		t2.food="Fishes";
		t2.gender="male";
		t2.name="Richard Parker";
		t2.climb();
		t2.eats();
		t2.mauls();
		t2.roar();
		t2.runs();
		t2.display();*/
		

	}

}
