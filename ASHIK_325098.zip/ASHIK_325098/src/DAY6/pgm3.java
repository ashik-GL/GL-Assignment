package DAY6;

import java.util.ArrayList;

public class pgm3 {
	ArrayList<student> std_al = new ArrayList<student>();
	
	public void create_al() {
		student s1 = new student("Bruce",100,99,98);
		student s2 = new student("Rachel",101,90,88);
		s1.average();
		s2.average();
		std_al.add(s1);
		std_al.add(s2);
	}


	public void display_al() {
		// TODO Auto-generated method stub
		for(student s:std_al) {
			System.out.println("Name: " + s.name 
								+ " Rollno: " + s.rollno
								+" Mark1: " + s.m1
								+" Mark2: " + s.m2
								+" Average: " + s.avg);
			
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm3 al=new pgm3();
		al.create_al();
		al.display_al();

	}



}
