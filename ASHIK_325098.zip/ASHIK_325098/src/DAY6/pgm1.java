package DAY6;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] st = {"Bruce","Joker","Rachel"};
		for(String s:st) {
			System.out.println(s);
		}
		

	}

}
