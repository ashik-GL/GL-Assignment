package DAY3;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int std[] = {77,55,91,79,65,92};
		float avg;
		int sum=0;
		
		for(int i=0;i<=5;i++) {
			sum=sum+std[i];
		}
		avg=(float)sum/6;
		System.out.println(avg);
		

	}

}
