package DAY3;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks[][] = {{1,20,5,4},{5,6,70,8},{10,90,12,11}};
		int i,j;
		
		int m=1;
		int[] rows = {0,0,0,0};
		for(i=0;i<3;i++) {
			for(j=0;j<4;j++) {
				System.out.print(marks[i][j] + "  ");
			}
			System.out.println("");
			
		}
		
		for(i=0;i<3;i++) {
			int c=0;
			for(j=0;j<4;j++) {
				
				rows[c]=marks[i][j];
				c++;
			}
			max(rows,m);
			m++;
		}
		
		
	}
	public static void max(int rows[],int m) {
		int i;
		int largest=rows[0];
		for(i=0;i<4;i++) {
			//System.out.println(rows[i]);
			if(rows[i]>largest) {
				largest=rows[i];			
			}
		}
		System.out.println("Row"+ m +" :"+largest);
		
		
		
	
	}

}
