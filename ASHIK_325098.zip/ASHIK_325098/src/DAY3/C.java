package DAY3;

public class C  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b1 = new B();
		b1.xyz=10;
		b1.abc=20;
		b1.show2();
		b1.show();

	}

}
