package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "I am learning java";
		int p=0,c=0;
		while(p!=-1) {
			p=s.indexOf(" ",p);
			if(p==-1)
				break;
			c++;
			p++;
		}
		System.out.println(c+1);
		

	}



}
