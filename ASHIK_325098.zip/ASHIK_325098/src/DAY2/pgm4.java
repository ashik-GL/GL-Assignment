package DAY2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int i;
		for(i=10;i<=50;i++) {
			if(i%5==0) {
				if(i==50) {
					System.out.println("50="+(sum+50));
				}
				else
					System.out.print(i+"+");
				sum=sum+i;
				
			}
			
		}
		

	}

}
