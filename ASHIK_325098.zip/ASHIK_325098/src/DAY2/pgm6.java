package DAY2;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//print nums btw 1 &30 div by 3 not div by 5
		int i;
		for(i=1;i<30;i++) {
			if(i%3==0 && i%5!=0) {
				System.out.print(i + "\t");
			}
		}

	}

}
