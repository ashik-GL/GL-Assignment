package DAY2;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k=0;
		for(i=0;i<5;i++) {
			for(j=i+1;j<5;j++) {
				System.out.print(" ");
			}
			for(k=0;k<=i;k++)
				System.out.print(k+1);
			System.out.print("\n");
				
		}

	}

}
