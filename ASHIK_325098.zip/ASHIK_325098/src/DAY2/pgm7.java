package DAY2;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//calc sum of all dig greater than 5
		int num = 58913;
		int sum=0;
		int rem=0;
		while(num!=0) {
			rem=num%10;
			if(rem>5) {
				sum=sum+rem;
			}
			num=num/10;
		}
		System.out.println(sum);
	}

}
