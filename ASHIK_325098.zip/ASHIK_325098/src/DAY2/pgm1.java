package DAY2;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=3;
		switch (s) {
		case 2: System.out.println("Two");break;
		case 5: System.out.println("Five");break;
		case 9: System.out.println("Nine");
		default:System.out.println("No match");
		}
		System.out.println("Out of Switch");

	}

}
