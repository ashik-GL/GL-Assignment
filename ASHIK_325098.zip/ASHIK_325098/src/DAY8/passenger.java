package DAY8;

public class passenger {
	int si;
	String name;
	String from;
	String to;
	int rate;
	int nos;
	int total;
	
	public void totalrate() {
		total=rate * nos;
	}

}
