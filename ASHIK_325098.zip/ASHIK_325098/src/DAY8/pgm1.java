package DAY8;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		operations op = new operations();
		ArrayList<passenger> al = new ArrayList<passenger>();
		al = op.read_excel();
		op.write_excel(al);
		
	}

}
