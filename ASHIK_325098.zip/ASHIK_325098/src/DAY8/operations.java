package DAY8;

import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class operations {
	
	public ArrayList<passenger> read_excel() {
		ArrayList<passenger> psg_al = new ArrayList<passenger>();
		
	
		for(int i=1;i<=4;i++) {
		try {
			passenger p1 = new passenger();
			//File f = new File("C:\\Training\\Book3.xlsx");
			File f=new File("C:\\Training\\book3.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(i);
			
			XSSFCell c = r.getCell(0);
			p1.si = (int)  c.getNumericCellValue();
			
			XSSFCell c0 = r.getCell(1);
			p1.name = c0.getStringCellValue();
			
			XSSFCell c1 = r.getCell(2);
			p1.from = c1.getStringCellValue();
			
			XSSFCell c2 = r.getCell(3);
			p1.to = c2.getStringCellValue();
			
			XSSFCell c3 = r.getCell(4);
			p1.rate = (int)  c3.getNumericCellValue();
			XSSFCell c4 = r.getCell(5);
			p1.nos = (int)  c4.getNumericCellValue();
			
			p1.totalrate();
			psg_al.add(p1);
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return psg_al;
	}
	
	public void write_excel(ArrayList<passenger> psg_al) {
		
		
		try {
			File f = new File("C:\\Training\\book3.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			int row=1;
			for(passenger p1:psg_al) {
				XSSFRow r = sh.getRow(row);
				XSSFCell c = r.createCell(6);
				
				c.setCellValue((double)p1.total);
				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
				row++;
				
			}
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	

}
