package DAY4;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r,c,d;
		int cmax=4;
		int dmax=1;
		for(r=0;r<3;r++) {
			for(c=0;c<cmax;c++) {
				System.out.print(" ");
			}
			for(d=0;d<dmax;d++) {
				System.out.print("1 ");
			}
			
			cmax=cmax-1;
			dmax++;
			System.out.println();
			
		}
		

	}

}
