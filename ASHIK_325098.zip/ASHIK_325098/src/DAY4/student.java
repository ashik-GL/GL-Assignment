package DAY4;

import DAY4.student;

public class student {
	int rollno;
	String name;
	int m1;
	int m2;
	float avg;
	public student(int rollno,String name,int m1) {
		// TODO Auto-generated constructor stub
		this.rollno=rollno;
		this.name=name;
		this.m1=m1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1 = new student(10,"Rakesh",85);
		
		s1.display();
		

	}

	private void display() {
		// TODO Auto-generated method stub
		System.out.println("Name:"+name);
		System.out.println("RollNo:"+rollno);
	}

}

