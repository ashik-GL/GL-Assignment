package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="I am working with Global Logic in Noida";
		int p=0,c=0,i=0;
		String[] str = new String[10]; 
		int len=s.length();
		//System.out.println(len);
		while(p!=-1) {
			p=s.indexOf(" ",p);
			if(p==-1) {
				str[i]=s.substring(c,len);
				//System.out.println(s.substring(c,len));
				break;
			}
			else {
				str[i]=s.substring(c,p);
				
				//System.out.println(s.substring(c,p));
			}
			i++;
			
			c=p+1;
			p++;
		}
		
		for(i=0;str[i]!=null;i++) {
			
		//	if(str[i]==null) {
		//		break;
		//	}
			System.out.println(str[i]);
		}
		

	}

}
