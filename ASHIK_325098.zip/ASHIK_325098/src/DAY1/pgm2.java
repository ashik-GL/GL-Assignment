package DAY1;

public class pgm2 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int num=1231,rem=0,rev=0,num2=num;
		while(num>0) {
			rem = num % 10;
			rev=(rev*10)+rem;
			num=num/10;
		}
	
	if(num2==rev) {
		System.out.println("Number is Palindrome");
	}
	else {
		System.out.println("Number is not Palindrome");
		
	}
	}

}
