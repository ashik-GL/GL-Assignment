package DAY1;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	    int n=10,i = 3, count, c;
	    System.out.println("2");
	    for(count = 2; count <= n; i++)  
	    {
	       
	        for(c = 2; c < i; c++)
	        {
	            if(i%c == 0)
	                break;
	        }

	        if(c == i)  
	        {
	            System.out.println(i);
	            count++;    
	        }

	    }
		
		

}
}
