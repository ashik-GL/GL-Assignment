package DAY1;

public class pgm10 {

	public static void main(String[] args) {
		 char msg='a';
		 
		 if(msg=='a' || msg=='e' ||msg=='i' ||msg=='o' ||msg=='u' ||msg=='A' ||msg=='E' ||msg=='I' ||msg=='O' ||msg=='U' ) {
			 System.out.println(msg+ " is a vowel");
		 }
		 else
			 System.out.println(msg +" is not a vowel");
		 char msg2='d';
		 if(msg2=='a' || msg2=='e' ||msg2=='i' ||msg2=='o' ||msg2=='u' ||msg2=='A' ||msg2=='E' ||msg2=='I' ||msg2=='O' ||msg2=='U' ) {
			 System.out.println(msg2 + " is a vowel");
		 }
		 else
			 System.out.println(msg2 +" is not a vowel");
}
}