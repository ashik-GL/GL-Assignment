package DAY1;

public class pgm8 {

	public static void main(String[] args) {
		System.out.println(10*10/5+3-1*4/2);
}
}