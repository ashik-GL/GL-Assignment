package DAY1;

public class pgm11 {

	public static void main(String[] args) {
		 int a=15,b=8,c=7;
		 if(a>b && a>c) {
			System.out.println(a+" is the largest"); 
		 }
		 else if(b>a && b>c) {
			 System.out.println(b+" is the largest");
		 }
		 else
			 System.out.println(c+" is the largest");
}
}