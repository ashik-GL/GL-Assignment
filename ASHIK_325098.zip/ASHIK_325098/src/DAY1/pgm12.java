package DAY1;

public class pgm12 {

	public static void main(String[] args) {
		int mark1=50,mark2=60,mark3=20;
		float totalperc=(mark1+mark2+mark3)/3;
		if(totalperc>=60)	{
			System.out.println("First Class");
		}
		else if(totalperc>=50 && totalperc<60)	{
			System.out.println("Second Class");
		}
		else if(totalperc>=35 && totalperc<=50)	{
			System.out.println("Pass Class");
		}
		else
			System.out.println("Fail");
		
}
}