package WEEKEND2;

import java.util.ArrayList;
import java.util.*;
public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line = "I have learnt loops, oops concepts, Inheritance, exception handling, arraylist and string handling";
		String line2 = line.replace(",","");
	
		ArrayList<String> ar_l=get_each_word(line2);
		ArrayList<String> ar_l2=count_vowels(ar_l);
		System.out.println(ar_l2);
		
		
		

	}

	public static ArrayList<String> count_vowels(ArrayList<String> ar_l) {
		// TODO Auto-generated method stub
		
		ArrayList<String> ar_l3 = new ArrayList<String>();
	    for (int i=0; i<ar_l.size(); i++) {
	    	String s=ar_l.get(i).toString();
	    	//System.out.println(s);
	    	int countv=0;
	    	for (int j = 0; j < s.length(); j++){
	    	    char c = s.charAt(j); 
	    	    if(c== 'a' || c== 'e' || c== 'i' || c== 'o' || c== 'u') {
		    		countv++;
		    	}
	    	   
	    	}
	    	if(countv>=3) {
	    		
				ar_l3.add(s);
	    	}
	    	
    } 
		//System.out.println(ar_l3);
		
		return ar_l3;
	}

	

	

	public static ArrayList<String> get_each_word(String line) {
		// TODO Auto-generated method stub
		int p=0,c=0,i=0;
		ArrayList<String>  ar_l = new ArrayList<String>();
		int len=line.length();
		//System.out.println(len);
		while(p!=-1) {
			p=line.indexOf(" ",p);
			if(p==-1) {
				
				ar_l.add(line.substring(c,len));
				//System.out.println(s.substring(c,len));
				break;
			}
			else {
			
				ar_l.add(line.substring(c,p));
				//System.out.println(s.substring(c,p));
			}
			i++;
			
			c=p+1;
			p++;
		}	
		
		return ar_l;
		
	}

}
