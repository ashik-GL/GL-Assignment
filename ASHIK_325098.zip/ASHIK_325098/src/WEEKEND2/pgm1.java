package WEEKEND2;

import java.util.ArrayList;

public class pgm1 {
	public static void main(String[] args) {
		 int n = 5; 
		 ArrayList<Integer> ar_l = new ArrayList<Integer>();
		 for(int i=10;i<=30;i++) {
			 if(i%2==0) {
				 ar_l.add(i);
			 }
		 }
		 System.out.println(ar_l);
	}
}
