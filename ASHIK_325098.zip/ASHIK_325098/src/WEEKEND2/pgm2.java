package WEEKEND2;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = new int[5];
		int num,rem,l=1000, sum = 0;
		int c=0;
		System.out.print("Armstrong numbers from 1 to 5:");
		for (int i = 1; i <= l; i++)
		{
			num = i;
			while (num > 0)
			{
				rem = num % 10;
				sum = sum + (rem*rem*rem);
				num = num / 10;
			}
	 
			if (sum == i)
			{
				arr[c]=i;
				c++;
			}
			sum = 0;
			
		}
		for(int i=0;i<5;i++) {
			System.out.println(arr[i]);
		}
		

	}

}
