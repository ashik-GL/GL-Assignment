package WEEKEND;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line = "Hello I am working at Global Logic";
		String[] words=extract_word(line);
		count_print(words);
	}

	public static String[] extract_word(String str) {
		// TODO Auto-generated method stub
		int len=str.length();
		
		String[] s = new String[10]; 
		//System.out.println(len);
		int p=0,c=0,i=0;
		while(p!=-1) {
			p=str.indexOf(" ",p);
			if(p==-1) {
				s[i]=str.substring(c,len);
				break;
			}
			else {
				s[i]=str.substring(c,p);	
			}
			i++;
			c=p+1;
			p++;
		}
		return s;
	}
	
	public static void count_print(String[] words) {
		// TODO Auto-generated method stub
		for(int i=0;words[i]!=null;i++) {
			if(words[i].length()>5) {
				System.out.println(words[i]);
			}
				
		}
			
	}
  
	
	
}
