package WEEKEND;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a1 = new int [7];
		int [] a2 = new int [5];
		int i,j;
		int c=0;
		int d=0;
		for(i=10;i<=30;i++) {
			if(i%3==0) {
				a1[c]=i;
				c++;
			}
			if(i%5==0) {
				a2[d]=i;
				d++;
			}
		}
		System.out.print("First Array");
		System.out.print(" Second Array");
		System.out.println("   Sum");
		for(i=0;i<7;i++) {
			for(j=0;j<5;j++) {
				if((a1[i]+a2[j])>30 && (a1[i]+a2[j])<40) {
					
				//	System.out.print("   "+a1[i]);
				//	System.out.print("   "+a2[j]);
				//	System.out.println("   "+(a1[i]+a2[j]));
					System.out.format("%7d", a1[i]);
					System.out.format("%12d", a2[j]);
					System.out.format("%10d", (a1[i]+a2[j]));
					System.out.print("\n");
				}
			}
		}
		

	}

}
