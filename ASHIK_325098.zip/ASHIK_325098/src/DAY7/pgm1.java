package DAY7;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<student> al = new ArrayList<student>();
		//operations op = new operations();
		operationsdemo op1 = new operationsdemo();
		//al=op.read_excel();
		
		//op.write_excel(al);
		
		al=op1.read_excel();
		
		op1.write_excel(al);

	}

}
