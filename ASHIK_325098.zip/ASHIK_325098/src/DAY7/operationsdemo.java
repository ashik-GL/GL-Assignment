package DAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class operationsdemo {
	
	public ArrayList<student> read_excel() {
		student s = new student();
		ArrayList<student> std_al = new ArrayList<student> ();
		File f=new File("C:\\Training\\book2.xlsx");
		//File f=new File("C:\Training\book2.xslx");
		FileInputStream fis;
		int nor=0;
		 try {
				fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				 XSSFSheet sh = wb.getSheet("Sheet1");
				 int firstrow = sh.getFirstRowNum();
				 int lastrow = sh.getLastRowNum();
				 nor = lastrow - firstrow + 1;
				 for(int i=1;i<=nor;i++) {

					 XSSFRow r = sh.getRow(i);
					 
					 XSSFCell c = r.getCell(0);
					 s.rollno = (int) c.getNumericCellValue();
					
					 XSSFCell c1 = r.getCell(1);
					 s.name = c1.getStringCellValue();
					 
					 
					 XSSFCell c2 = r.getCell(2);
					 s.m1 = (int) c2.getNumericCellValue();
					 
					 XSSFCell c3 = r.getCell(3);
					 s.m2 = (int) c3.getNumericCellValue();
					 
					 s.average();
					 std_al.add(s);
				 
				 }
				 
		 } catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}	
		
		 
		 
		return std_al;
		
	}

	public void write_excel(ArrayList<student> std_al) {
		try {

			int row=1;
		File f=new File("C:\\Training\\book2.xlsx");
		
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		 XSSFSheet sh = wb.getSheet("Sheet1");
		 for(student s: std_al) {
		 XSSFRow r = sh.getRow(row);
		
		 XSSFCell c = r.createCell(4);
		 c.setCellValue((double)s.avg);
		 FileOutputStream fos = new FileOutputStream(f);
		 wb.write(fos);
		 
		 row++;
		 
		 
		 }
		
		 
		}
		
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		
		}
	}

}
