package DAY5;

public class pgm1 {
	public static void main(String[] args) {
		int n=10,m=0,p;
		int a[]= {1,2,3};
		p=n/m;
		System.out.println(p);
		//System.out.println(a[3]);
	}
}
