package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class operations {
	
	public student read_excel(int r1) {
		student s = new student();
		try {
			File f=new File("C:\\Training\\book2.xlsx");
			//File f=new File("C:\Training\book2.xslx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			 XSSFSheet sh = wb.getSheet("Sheet1");
			 XSSFRow r = sh.getRow(r1);
			 
			 XSSFCell c = r.getCell(0);
			 s.rollno = (int) c.getNumericCellValue();
			
			 XSSFCell c1 = r.getCell(1);
			 s.name = c1.getStringCellValue();
			 
			 
			 XSSFCell c2 = r.getCell(2);
			 s.m1 = (int) c2.getNumericCellValue();
			 
			 XSSFCell c3 = r.getCell(3);
			 s.m2 = (int) c3.getNumericCellValue();
			 
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return s;
		
	}

	public void write_excel(student s1,int r1) {
		student s = new student();
		try {
		File f=new File("C:\\Training\\book2.xlsx");
		//File f=new File("C:\Training\book2.xslx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		 XSSFSheet sh = wb.getSheet("Sheet1");
		 XSSFRow r = sh.getRow(r1);
		
		 XSSFCell c = r.createCell(4);
		 c.setCellValue((double)s1.avg);
		 FileOutputStream fos = new FileOutputStream(f);
		 wb.write(fos);
		 
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
