package DAY5;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		operations op = new operations();
		
			
		for(int i=1;i<=2;i++) {
			student s1=op.read_excel(i);
			s1.average();
			op.write_excel(s1,i);
		}

	}

}
