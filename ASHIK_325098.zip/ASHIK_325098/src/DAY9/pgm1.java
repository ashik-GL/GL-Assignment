package DAY9;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encap e1=new encap();
		e1.setAccount_bal(15000);
		e1.setAccount_no(101);
		
		System.out.println("Account No is:" + e1.getAccount_no());
		System.out.println("Account balance is:" + e1.getAccount_bal());


	}

}
