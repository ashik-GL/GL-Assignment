package DAY9;

public class hdfc extends pgm2 {


	public float get_roi() {
		// TODO Auto-generated method stub
		return 9.5f;
	}

}
