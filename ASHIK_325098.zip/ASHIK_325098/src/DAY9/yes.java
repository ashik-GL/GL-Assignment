package DAY9;

public class yes extends pgm2{
	public float get_roi() {
		return 7.5f;
	}
}
