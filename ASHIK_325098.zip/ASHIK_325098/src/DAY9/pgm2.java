package DAY9;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		yes y = new yes();
		hdfc h = new hdfc();
		
		float roi;
		System.out.println(y.get_roi());
		System.out.println(h.get_roi());

	}

}
